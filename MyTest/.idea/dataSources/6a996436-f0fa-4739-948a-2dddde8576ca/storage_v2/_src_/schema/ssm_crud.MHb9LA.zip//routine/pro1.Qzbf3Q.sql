create procedure pro1(IN n int)
  BEGIN                                                                 /*开始*/
    DECLARE num001 INT;
    DECLARE chineseSco INT;
    DECLARE mathSco INT;
    DECLARE englishSco INT;
    SET num001 = 1;                             /*设置num001=1,num002=10*/
    SET chineseSco = 100,mathSco = 100,englishSco = 100;
    WHILE n - num001 >= 0 DO                                     /*当num001小于等于n时执行下面的操作*/
      INSERT INTO tbl_student(stu_id,stu_name,chinese,math,english)
      VALUES(num001,CONCAT("student" , num001) , chineseSco,mathSco,englishSco);        /*在test表中插入数据test_name=zhangsan+num001,test_num=num002，contat意为将张三和num001连起来*/
      SET num001=num001+1;             /*设置num001=num001+1,num002=num002*2*/
      SET chineseSco = FLOOR(RAND()*101),mathSco = FLOOR(RAND()*101),englishSco = FLOOR(RAND()*101);
    END WHILE;                                                          /*当num>100时，不再执行插入操作循环结束*/
  END;

